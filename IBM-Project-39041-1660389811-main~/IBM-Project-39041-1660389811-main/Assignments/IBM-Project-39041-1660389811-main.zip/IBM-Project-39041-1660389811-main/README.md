# IBM-Project-45981-1660733831
A Novel Method for Handwritten Digit Recognition System
