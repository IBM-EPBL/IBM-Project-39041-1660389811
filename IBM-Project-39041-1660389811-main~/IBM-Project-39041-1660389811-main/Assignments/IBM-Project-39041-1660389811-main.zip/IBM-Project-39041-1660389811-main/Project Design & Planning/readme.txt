Project Design & Planning stages are listed in this folder
Those are:
Ideation Phase
Project Design Phase-1
Project Design Phase-2
Project Planning
